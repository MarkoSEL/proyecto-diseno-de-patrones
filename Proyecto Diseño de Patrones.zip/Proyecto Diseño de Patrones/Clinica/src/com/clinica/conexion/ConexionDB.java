package com.clinica.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
        
public class ConexionDB {
    private static final String URL = "jdbc:mysql://localhost:3306/Clinica?useSSL=false&serverTimezone=UTC";
    
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    private static ConexionDB instancia;

    private Connection cnn;

    private ConexionDB() {
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            this.cnn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión a 'Clinica' establecida.");
            
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Driver MySQL no encontrado. " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Error: No se encontró el driver de MySQL (mysql-connector-j.jar).\n" +
                "Asegúrate de agregarlo a las 'Libraries' del proyecto.", 
                "Error de Driver", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            System.err.println("Error en la conexión a la base de datos: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "Error de conexión a la Base de Datos.\n" +
                "Verifica la URL, usuario, contraseña y que el servidor MySQL esté activo.", 
                "Error de Conexión", JOptionPane.ERROR_MESSAGE);
            System.exit(1); 
        }
    }

    public static synchronized ConexionDB getInstancia() {
        if (instancia == null) {
            instancia = new ConexionDB();
        }
        return instancia;
    }

    public Connection getConexion() {
        return cnn;
    }

    public void cerrar() {
        try {
            if (cnn != null && !cnn.isClosed()) {
                cnn.close();
                System.out.println("Conexión cerrada.");
            }
        } catch (SQLException e) {
            System.err.println("Error al cerrar la conexión: " + e.getMessage());
        }
    }
}
