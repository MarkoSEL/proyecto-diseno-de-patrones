package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Cita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CitaDAO {

    private final Connection cnn;

    public CitaDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }

    public boolean registrarCita(Cita cita) {
        String sql = "INSERT INTO Citas (id_paciente, id_medico, id_especialidad, fecha_hora, " +
                     "malestar_motivo, costo_consulta_registrado, estado_pago) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, cita.getIdPaciente());
            ps.setInt(2, cita.getIdMedico());
            ps.setInt(3, cita.getIdEspecialidad());
            ps.setTimestamp(4, Timestamp.valueOf(cita.getFechaHora()));
            ps.setString(5, cita.getMalestarMotivo());
            ps.setDouble(6, cita.getCostoConsultaRegistrado());
            ps.setString(7, "PENDIENTE"); // Por defecto

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al registrar cita: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al registrar cita: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public List<Cita> listarCitasPorPaciente(int idPaciente) {
        List<Cita> citas = new ArrayList<>();
        String sql = "SELECT c.*, e.nombre AS nombre_especialidad, " +
                     "CONCAT(u.nombres, ' ', u.apellidos) AS nombre_medico " +
                     "FROM Citas c " +
                     "JOIN Especialidades e ON c.id_especialidad = e.id_especialidad " +
                     "JOIN Medicos m ON c.id_medico = m.id_medico " +
                     "JOIN Usuarios u ON m.id_usuario = u.id_usuario " +
                     "WHERE c.id_paciente = ? ORDER BY c.fecha_hora DESC";
        
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idPaciente);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cita cita = new Cita();
                cita.setIdCita(rs.getInt("id_cita"));
                cita.setIdPaciente(rs.getInt("id_paciente"));
                cita.setIdMedico(rs.getInt("id_medico"));
                cita.setIdEspecialidad(rs.getInt("id_especialidad"));
                cita.setFechaHora(rs.getTimestamp("fecha_hora").toLocalDateTime());
                cita.setMalestarMotivo(rs.getString("malestar_motivo"));
                cita.setCostoConsultaRegistrado(rs.getDouble("costo_consulta_registrado"));
                cita.setEstadoPago(rs.getString("estado_pago"));
                
                cita.setNombreEspecialidad(rs.getString("nombre_especialidad"));
                cita.setNombreMedico(rs.getString("nombre_medico"));
                
                citas.add(cita);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar citas: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar citas: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return citas;
    }
    
    public boolean modificarCita(Cita cita) {
        String sql = "UPDATE Citas SET id_medico = ?, id_especialidad = ?, fecha_hora = ?, " +
                     "malestar_motivo = ?, costo_consulta_registrado = ? " +
                     "WHERE id_cita = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, cita.getIdMedico());
            ps.setInt(2, cita.getIdEspecialidad());
            ps.setTimestamp(3, Timestamp.valueOf(cita.getFechaHora()));
            ps.setString(4, cita.getMalestarMotivo());
            ps.setDouble(5, cita.getCostoConsultaRegistrado());
            ps.setInt(6, cita.getIdCita());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al modificar cita: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al modificar cita: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }

    public boolean eliminarCita(int idCita) {
        String sql = "DELETE FROM Citas WHERE id_cita = ?";
        PreparedStatement ps = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setInt(1, idCita);
            
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar cita: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al eliminar cita: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            try {
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
    
    public List<Cita> listarCitasPagadasPorDni(String dni) {
        List<Cita> citas = new ArrayList<>();
        // Unimos con Pacientes (p) para filtrar por DNI
        String sql = "SELECT c.*, e.nombre AS nombre_especialidad, " +
                     "CONCAT(u.nombres, ' ', u.apellidos) AS nombre_medico, " +
                     "CONCAT(p.nombres, ' ', p.apellidos) AS nombre_paciente " +
                     "FROM Citas c " +
                     "JOIN Pacientes p ON c.id_paciente = p.id_paciente " +
                     "JOIN Especialidades e ON c.id_especialidad = e.id_especialidad " +
                     "JOIN Medicos m ON c.id_medico = m.id_medico " +
                     "JOIN Usuarios u ON m.id_usuario = u.id_usuario " +
                     "WHERE p.dni = ? AND c.estado_pago = 'PAGADA' " +
                     "AND c.id_cita NOT IN (SELECT id_cita FROM Consultas) " + // Opcional: Ocultar si ya fue atendida
                     "ORDER BY c.fecha_hora ASC"; // Mostrar la más próxima primero
        
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setString(1, dni);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cita cita = new Cita();
                cita.setIdCita(rs.getInt("id_cita"));
                cita.setIdPaciente(rs.getInt("id_paciente"));
                cita.setIdMedico(rs.getInt("id_medico"));
                cita.setIdEspecialidad(rs.getInt("id_especialidad"));
                cita.setFechaHora(rs.getTimestamp("fecha_hora").toLocalDateTime());
                cita.setMalestarMotivo(rs.getString("malestar_motivo"));
                cita.setCostoConsultaRegistrado(rs.getDouble("costo_consulta_registrado"));
                cita.setEstadoPago(rs.getString("estado_pago"));
                
                cita.setNombreEspecialidad(rs.getString("nombre_especialidad"));
                cita.setNombreMedico(rs.getString("nombre_medico"));
                cita.setNombrePaciente(rs.getString("nombre_paciente")); // Nombre del paciente
                
                citas.add(cita);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar citas pagadas: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al listar citas pagadas: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return citas;
    }
}