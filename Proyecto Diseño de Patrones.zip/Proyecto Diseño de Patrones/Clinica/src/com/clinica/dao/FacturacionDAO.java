package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.Factura;
import com.clinica.modelo.FacturaDetalle;
import com.clinica.modelo.ItemPorPagar;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class FacturacionDAO {

    private final Connection cnn;

    public FacturacionDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }
    
    public List<ItemPorPagar> getItemsPorPagar(int idPaciente) {
        List<ItemPorPagar> items = new ArrayList<>();
        
        // --- SQL ACTUALIZADO ---
        String sqlCitas = "SELECT 'CONSULTA' AS tipoItem, c.id_cita AS idReferencia, 0 AS idMedicina, " +
                          "CONCAT('Consulta ', e.nombre) AS descripcion, 1 AS cantidad, " +
                          "c.costo_consulta_registrado AS precio_venta_unitario, " +
                          "0 AS costo_unitario, " +
                          "9999 AS stock_disponible " + // Stock 'dummy' para consulta
                          "FROM Citas c " +
                          "JOIN Especialidades e ON c.id_especialidad = e.id_especialidad " +
                          "WHERE c.id_paciente = ? AND c.estado_pago = 'PENDIENTE'";

        // --- SQL ACTUALIZADO (añade m.cantidad_stock) ---
        String sqlMedicinas = "SELECT 'MEDICINA' AS tipoItem, rm.id_receta AS idReferencia, m.id_medicina AS idMedicina, " +
                              "m.nombre AS descripcion, rm.cantidad_prescrita AS cantidad, " +
                              "m.precio_venta_unitario, m.costo_unitario, " +
                              "m.cantidad_stock AS stock_disponible " + // Stock real
                              "FROM Receta_Medicamentos rm " +
                              "JOIN Medicinas m ON rm.id_medicina = m.id_medicina " +
                              "JOIN Consultas con ON rm.id_consulta = con.id_consulta " +
                              "JOIN Citas c ON con.id_cita = c.id_cita " +
                              "WHERE c.id_paciente = ? AND rm.id_receta NOT IN " +
                              "(SELECT id_receta_medicamento FROM Factura_Detalle WHERE id_receta_medicamento IS NOT NULL)";

        String sqlUnion = sqlCitas + " UNION ALL " + sqlMedicinas;
        
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sqlUnion);
            ps.setInt(1, idPaciente);
            ps.setInt(2, idPaciente);
            rs = ps.executeQuery();

            while (rs.next()) {
                // --- CONSTRUCTOR ACTUALIZADO ---
                items.add(new ItemPorPagar(
                    rs.getString("tipoItem"),
                    rs.getInt("idReferencia"),
                    rs.getInt("idMedicina"),
                    rs.getString("descripcion"),
                    rs.getInt("cantidad"),
                    rs.getDouble("precio_venta_unitario"),
                    rs.getDouble("costo_unitario"),
                    rs.getInt("stock_disponible") // Nuevo campo
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener items por pagar: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al buscar deudas: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return items;
    }
    
    // El método registrarPago() que ya tienes (el de la corrección anterior)
    // está perfecto y no necesita cambios, ya que lee la cantidad
    // final del objeto FacturaDetalle.
    
    public boolean registrarPago(Factura factura, List<FacturaDetalle> detalles) {
        PreparedStatement psFactura = null;
        PreparedStatement psDetalle = null;
        PreparedStatement psUpdateCita = null;
        PreparedStatement psUpdateStock = null;
        ResultSet rsFactura = null;

        String sqlFactura = "INSERT INTO Facturas (id_paciente, metodo_pago, subtotal, igv, total_importe) " +
                            "VALUES (?, ?, ?, ?, ?)";
        
        String sqlDetalle = "INSERT INTO Factura_Detalle (id_factura, id_cita, id_medicina, id_receta_medicamento, " +
                            "descripcion, cantidad_vendida, precio_venta_unitario, costo_unitario) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        String sqlUpdateCita = "UPDATE Citas SET estado_pago = 'PAGADA' WHERE id_cita = ?";
        String sqlUpdateStock = "UPDATE Medicinas SET cantidad_stock = cantidad_stock - ? WHERE id_medicina = ?";

        try {
            cnn.setAutoCommit(false);

            psFactura = cnn.prepareStatement(sqlFactura, Statement.RETURN_GENERATED_KEYS);
            psFactura.setInt(1, factura.getIdPaciente());
            psFactura.setString(2, factura.getMetodoPago());
            psFactura.setDouble(3, factura.getSubtotal());
            psFactura.setDouble(4, factura.getIgv());
            psFactura.setDouble(5, factura.getTotalImporte());
            psFactura.executeUpdate();

            rsFactura = psFactura.getGeneratedKeys();
            if (!rsFactura.next()) {
                throw new SQLException("Falló al crear la factura, no se obtuvo ID.");
            }
            int idFacturaNueva = rsFactura.getInt(1);

            psDetalle = cnn.prepareStatement(sqlDetalle);
            psUpdateCita = cnn.prepareStatement(sqlUpdateCita);
            psUpdateStock = cnn.prepareStatement(sqlUpdateStock);

            for (FacturaDetalle det : detalles) {
                psDetalle.setInt(1, idFacturaNueva);
                psDetalle.setObject(2, det.getIdCita());
                psDetalle.setObject(3, det.getIdMedicina());
                psDetalle.setObject(4, det.getIdRecetaMedicamento());
                psDetalle.setString(5, det.getDescripcion());
                psDetalle.setInt(6, det.getCantidadVendida());
                psDetalle.setDouble(7, det.getPrecioVentaUnitario());
                psDetalle.setDouble(8, det.getCostoUnitario());
                psDetalle.addBatch();

                if (det.getIdCita() != null) {
                    psUpdateCita.setInt(1, det.getIdCita());
                    psUpdateCita.addBatch();
                }

                if (det.getIdMedicina() != null) {
                    psUpdateStock.setInt(1, det.getCantidadVendida());
                    psUpdateStock.setInt(2, det.getIdMedicina());
                    psUpdateStock.addBatch();
                }
            }

            psDetalle.executeBatch();
            psUpdateCita.executeBatch();
            psUpdateStock.executeBatch();

            cnn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("Error en la transacción de pago: " + e.getMessage());
            try {
                if (cnn != null) {
                    cnn.rollback();
                    JOptionPane.showMessageDialog(null, "Error al registrar pago: " + e.getMessage(), "Error de Transacción", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException se) {
                System.err.println("Error en el rollback: " + se.getMessage());
            }
            return false;
        } finally {
            try {
                if (rsFactura != null) rsFactura.close();
                if (psFactura != null) psFactura.close();
                if (psDetalle != null) psDetalle.close();
                if (psUpdateCita != null) psUpdateCita.close();
                if (psUpdateStock != null) psUpdateStock.close();
                if (cnn != null) {
                    cnn.setAutoCommit(true);
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
    }
}