package com.clinica.dao;

import com.clinica.conexion.ConexionDB;
import com.clinica.modelo.ReporteItem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ReporteDAO {

    private final Connection cnn;

    public ReporteDAO() {
        this.cnn = ConexionDB.getInstancia().getConexion();
    }
    
    public List<ReporteItem> generarReportePorMedico(LocalDate fechaInicio, LocalDate fechaFin) {
        List<ReporteItem> reporte = new ArrayList<>();
        
        String sql = "SELECT " +
            "    u.nombres, u.apellidos, " +
            "    SUM(CASE WHEN fd.id_cita IS NOT NULL THEN 1 ELSE 0 END) AS numero_consultas, " +
            "    SUM(CASE WHEN fd.id_cita IS NOT NULL THEN fd.precio_venta_unitario ELSE 0 END) AS ingreso_consultas, " +
            "    SUM(CASE WHEN fd.id_medicina IS NOT NULL THEN fd.cantidad_vendida ELSE 0 END) AS numero_ventas_medicina, " +
            "    SUM(CASE WHEN fd.id_medicina IS NOT NULL THEN fd.precio_venta_unitario * fd.cantidad_vendida ELSE 0 END) AS ingreso_medicinas, " +
            "    SUM(CASE WHEN fd.id_medicina IS NOT NULL THEN fd.costo_unitario * fd.cantidad_vendida ELSE 0 END) AS costo_medicinas " +
            "FROM Facturas f " +
            "JOIN Factura_Detalle fd ON f.id_factura = fd.id_factura " +
            "LEFT JOIN Citas c ON fd.id_cita = c.id_cita " +
            "LEFT JOIN Medicos m ON c.id_medico = m.id_medico " +
            "LEFT JOIN Usuarios u ON m.id_usuario = u.id_usuario " +
            "WHERE DATE(f.fecha_hora) BETWEEN ? AND ? " +
            "GROUP BY u.nombres, u.apellidos " +
            "ORDER BY u.apellidos, u.nombres";
        
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = cnn.prepareStatement(sql);
            ps.setObject(1, fechaInicio);
            ps.setObject(2, fechaFin);
            rs = ps.executeQuery();

            while (rs.next()) {
                ReporteItem item = new ReporteItem();
                item.setAgrupador(rs.getString("nombres") + " " + rs.getString("apellidos"));
                item.setNumeroConsultas(rs.getInt("numero_consultas"));
                item.setIngresoConsultas(rs.getDouble("ingreso_consultas"));
                item.setNumeroVentasMedicina(rs.getInt("numero_ventas_medicina"));
                item.setIngresoMedicinas(rs.getDouble("ingreso_medicinas"));
                item.setCostoMedicinas(rs.getDouble("costo_medicinas"));
                reporte.add(item);
            }
        } catch (SQLException e) {
            System.err.println("Error al generar reporte: " + e.getMessage());
            JOptionPane.showMessageDialog(null, "Error al generar reporte: " + e.getMessage(), "Error DB", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        return reporte;
    }
}