package com.clinica.factory;

import com.clinica.dao.CitaDAO;
import com.clinica.dao.ConsultaDAO;
import com.clinica.dao.EspecialidadDAO;
import com.clinica.dao.FacturacionDAO;
import com.clinica.dao.MedicinaDAO;
import com.clinica.dao.MedicoDAO;
import com.clinica.dao.PacienteDAO;
import com.clinica.dao.ReporteDAO;
import com.clinica.dao.UsuarioDAO;

public class DaoFactory {

    private DaoFactory() {
    }

    public static UsuarioDAO getUsuarioDAO() {
        return new UsuarioDAO();
    }

    public static PacienteDAO getPacienteDAO() {
        return new PacienteDAO();
    }

    public static MedicoDAO getMedicoDAO() {
        return new MedicoDAO();
    }

    public static EspecialidadDAO getEspecialidadDAO() {
        return new EspecialidadDAO();
    }

    public static CitaDAO getCitaDAO() {
        return new CitaDAO();
    }

    public static ConsultaDAO getConsultaDAO() {
        return new ConsultaDAO();
    }

    public static MedicinaDAO getMedicinaDAO() {
        return new MedicinaDAO();
    }

    public static FacturacionDAO getFacturacionDAO() {
        return new FacturacionDAO();
    }
    
    public static ReporteDAO getReporteDAO() {
        return new ReporteDAO();
    }
}