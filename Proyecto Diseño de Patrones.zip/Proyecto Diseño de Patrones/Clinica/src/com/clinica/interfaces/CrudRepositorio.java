package com.clinica.interfaces;

import java.util.List;

public interface CrudRepositorio<T> {

    boolean registrar(T t);

    List<T> listar(String filtro);

    boolean modificar(T t);

    boolean eliminar(int id);
}