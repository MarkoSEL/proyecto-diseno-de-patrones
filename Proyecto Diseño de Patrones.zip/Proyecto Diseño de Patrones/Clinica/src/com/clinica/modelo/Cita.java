package com.clinica.modelo;

import java.time.LocalDateTime;

public class Cita {

    private int idCita;
    private int idPaciente;
    private int idMedico;
    private int idEspecialidad;
    private LocalDateTime fechaHora;
    private String malestarMotivo;
    private double costoConsultaRegistrado;
    private String estadoPago;

    private String nombrePaciente;
    private String nombreMedico;
    private String nombreEspecialidad;

    public Cita() {
    }

    public int getIdCita() {
        return idCita;
    }

    public void setIdCita(int idCita) {
        this.idCita = idCita;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public int getIdEspecialidad() {
        return idEspecialidad;
    }

    public void setIdEspecialidad(int idEspecialidad) {
        this.idEspecialidad = idEspecialidad;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getMalestarMotivo() {
        return malestarMotivo;
    }

    public void setMalestarMotivo(String malestarMotivo) {
        this.malestarMotivo = malestarMotivo;
    }

    public double getCostoConsultaRegistrado() {
        return costoConsultaRegistrado;
    }

    public void setCostoConsultaRegistrado(double costoConsultaRegistrado) {
        this.costoConsultaRegistrado = costoConsultaRegistrado;
    }

    public String getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(String estadoPago) {
        this.estadoPago = estadoPago;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public void setNombrePaciente(String nombrePaciente) {
        this.nombrePaciente = nombrePaciente;
    }

    public String getNombreMedico() {
        return nombreMedico;
    }

    public void setNombreMedico(String nombreMedico) {
        this.nombreMedico = nombreMedico;
    }

    public String getNombreEspecialidad() {
        return nombreEspecialidad;
    }

    public void setNombreEspecialidad(String nombreEspecialidad) {
        this.nombreEspecialidad = nombreEspecialidad;
    }
}