package com.clinica.modelo;

public class FacturaDetalle {

    private int idFacturaDetalle;
    private int idFactura;
    private Integer idCita;
    private Integer idMedicina;
    private Integer idRecetaMedicamento;
    private String descripcion;
    private int cantidadVendida;
    private double precioVentaUnitario;
    private double costoUnitario;

    public FacturaDetalle() {
    }

    public Integer getIdRecetaMedicamento() {
        return idRecetaMedicamento;
    }

    public void setIdRecetaMedicamento(Integer idRecetaMedicamento) {
        this.idRecetaMedicamento = idRecetaMedicamento;
    }

    public int getIdFacturaDetalle() {
        return idFacturaDetalle;
    }

    public void setIdFacturaDetalle(int idFacturaDetalle) {
        this.idFacturaDetalle = idFacturaDetalle;
    }

    public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public Integer getIdCita() {
        return idCita;
    }

    public void setIdCita(Integer idCita) {
        this.idCita = idCita;
    }

    public Integer getIdMedicina() {
        return idMedicina;
    }

    public void setIdMedicina(Integer idMedicina) {
        this.idMedicina = idMedicina;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCantidadVendida() {
        return cantidadVendida;
    }

    public void setCantidadVendida(int cantidadVendida) {
        this.cantidadVendida = cantidadVendida;
    }

    public double getPrecioVentaUnitario() {
        return precioVentaUnitario;
    }

    public void setPrecioVentaUnitario(double precioVentaUnitario) {
        this.precioVentaUnitario = precioVentaUnitario;
    }

    public double getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(double costoUnitario) {
        this.costoUnitario = costoUnitario;
    }
}