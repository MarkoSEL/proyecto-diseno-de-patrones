package com.clinica.modelo;

public class ItemPorPagar {
    
    private String tipoItem; 
    private int idReferencia; 
    private int idMedicina;
    private String descripcion;
    private int cantidad;
    private double precioUnitarioVenta;
    private double costoUnitario;
    private int stockDisponible;

    public ItemPorPagar(String tipoItem, int idReferencia, int idMedicina, String descripcion, int cantidad, double precioUnitarioVenta, double costoUnitario, int stockDisponible) {
        this.tipoItem = tipoItem;
        this.idReferencia = idReferencia;
        this.idMedicina = idMedicina;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precioUnitarioVenta = precioUnitarioVenta;
        this.costoUnitario = costoUnitario;
        this.stockDisponible = stockDisponible;
    }
    
    public double getImporteTotal() {
        return this.cantidad * this.precioUnitarioVenta;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    public int getStockDisponible() {
        return stockDisponible;
    }

    public String getTipoItem() {
        return tipoItem;
    }

    public void setTipoItem(String tipoItem) {
        this.tipoItem = tipoItem;
    }

    public int getIdReferencia() {
        return idReferencia;
    }

    public void setIdReferencia(int idReferencia) {
        this.idReferencia = idReferencia;
    }

    public int getIdMedicina() {
        return idMedicina;
    }

    public void setIdMedicina(int idMedicina) {
        this.idMedicina = idMedicina;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioUnitarioVenta() {
        return precioUnitarioVenta;
    }

    public void setPrecioUnitarioVenta(double precioUnitarioVenta) {
        this.precioUnitarioVenta = precioUnitarioVenta;
    }

    public double getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(double costoUnitario) {
        this.costoUnitario = costoUnitario;
    }
}