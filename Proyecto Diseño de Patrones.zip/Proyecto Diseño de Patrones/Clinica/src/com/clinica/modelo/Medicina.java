package com.clinica.modelo;

public class Medicina {

    private int idMedicina;
    private String nombre;
    private int cantidadStock;
    private double costoUnitario;
    private double precioVentaUnitario;

    public Medicina() {
    }

    public Medicina(int idMedicina, String nombre, int cantidadStock, double costoUnitario, double precioVentaUnitario) {
        this.idMedicina = idMedicina;
        this.nombre = nombre;
        this.cantidadStock = cantidadStock;
        this.costoUnitario = costoUnitario;
        this.precioVentaUnitario = precioVentaUnitario;
    }

    public int getIdMedicina() {
        return idMedicina;
    }

    public void setIdMedicina(int idMedicina) {
        this.idMedicina = idMedicina;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public double getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(double costoUnitario) {
        this.costoUnitario = costoUnitario;
    }

    public double getPrecioVentaUnitario() {
        return precioVentaUnitario;
    }

    public void setPrecioVentaUnitario(double precioVentaUnitario) {
        this.precioVentaUnitario = precioVentaUnitario;
    }
    
    @Override
    public String toString() {
        // Para JComboBox o JList
        return nombre;
    }
}