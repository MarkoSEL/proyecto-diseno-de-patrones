package com.clinica.modelo;

public class Medico extends Persona {

    private int idMedico;
    private int idUsuario; 
    private String codigoMedico;
    private String nombresCompletos;
    private String usuarioLogin; 

    public Medico() {
        super();
    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getCodigoMedico() {
        return codigoMedico;
    }

    public void setCodigoMedico(String codigoMedico) {
        this.codigoMedico = codigoMedico;
    }

    public String getCelular() {
        return super.getTelefono();
    }

    public void setCelular(String celular) {
        super.setTelefono(celular);
    }

    public String getNombresCompletos() {
        return nombresCompletos;
    }

    public void setNombresCompletos(String nombresCompletos) {
        this.nombresCompletos = nombresCompletos;
    }
    
    public void setDatosUsuario(String nombres, String apellidos, String dni, String correo, String usuario) {
        super.setNombres(nombres);
        super.setApellidos(apellidos);
        super.setDni(dni);
        super.setCorreo(correo);
        this.usuarioLogin = usuario;
    }

    public String getUsuario() {
        return usuarioLogin;
    }
    
    @Override
    public String toString() {
        if (nombresCompletos != null && !nombresCompletos.isEmpty()) {
            return nombresCompletos;
        }
        return super.toString();
    }
}