package com.clinica.modelo;

import java.time.LocalDate;
import java.time.Period;

public class Paciente extends Persona {

    private int idPaciente;
    private LocalDate fechaNacimiento;
    private String genero;
    private String ocupacion;
    private String direccion;

    public Paciente() {
        super();
    }

    public Paciente(String dni, String nombres, String apellidos, LocalDate fechaNacimiento, String genero, String ocupacion, String direccion, String telefono, String email) {
        super(dni, nombres, apellidos, email, telefono);
        this.fechaNacimiento = fechaNacimiento;
        this.genero = genero;
        this.ocupacion = ocupacion;
        this.direccion = direccion;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEmail() {
        return super.getCorreo();
    }

    public void setEmail(String email) {
        super.setCorreo(email);
    }
    
    public int getEdad() {
        if (this.fechaNacimiento == null) {
            return 0;
        }
        return Period.between(this.fechaNacimiento, LocalDate.now()).getYears();
    }
}