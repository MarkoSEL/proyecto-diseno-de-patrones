package com.clinica.modelo;

public class Usuario extends Persona {

    private int idUsuario;
    private String usuario;
    private String contraseña;
    private String tipoUsuario;

    public Usuario() {
        super();
    }

    public Usuario(String usuario, String contraseña) {
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public Usuario(int idUsuario, String nombres, String apellidos, String dni, String correo, String usuario, String tipoUsuario) {
        super(dni, nombres, apellidos, correo, null); // Usuario no suele tener teléfono en esta tabla, pasamos null
        this.idUsuario = idUsuario;
        this.usuario = usuario;
        this.tipoUsuario = tipoUsuario;
    }

    public Usuario(String nombres, String apellidos, String dni, String correo, String usuario, String contraseña, String tipoUsuario) {
        super(dni, nombres, apellidos, correo, null);
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.tipoUsuario = tipoUsuario;
    }


    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
}