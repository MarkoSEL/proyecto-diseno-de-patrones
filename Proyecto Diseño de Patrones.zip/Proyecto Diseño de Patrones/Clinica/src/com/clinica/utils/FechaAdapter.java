package com.clinica.utils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class FechaAdapter {

    public static LocalDate convertirALocalDate(Date dateToConvert) {
        if (dateToConvert == null) return null;
        return dateToConvert.toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();
    }

    public static Date convertirADate(LocalDate dateToConvert) {
        if (dateToConvert == null) return null;
        return Date.from(dateToConvert.atStartOfDay()
            .atZone(ZoneId.systemDefault())
            .toInstant());
    }
}