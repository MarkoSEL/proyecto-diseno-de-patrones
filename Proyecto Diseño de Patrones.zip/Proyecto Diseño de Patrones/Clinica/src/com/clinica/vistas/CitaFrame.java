package com.clinica.vistas;

import com.clinica.dao.CitaDAO;
import com.clinica.dao.EspecialidadDAO;
import com.clinica.dao.MedicoDAO;
import com.clinica.dao.PacienteDAO;
import com.clinica.modelo.Cita;
import com.clinica.modelo.Especialidad;
import com.clinica.modelo.Medico;
import com.clinica.modelo.Paciente;
import java.awt.event.ItemEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CitaFrame extends javax.swing.JFrame {

    private final PacienteDAO pacienteDAO;
    private final EspecialidadDAO especialidadDAO;
    private final MedicoDAO medicoDAO;
    private final CitaDAO citaDAO;
    
    private Paciente pacienteActual;
    private List<Especialidad> listaEspecialidades;
    private List<Cita> listaCitasPaciente;
    private DefaultTableModel citasTableModel;
    private Cita citaSeleccionada;

    public CitaFrame() {
        initComponents();
        this.pacienteDAO = new PacienteDAO();
        this.especialidadDAO = new EspecialidadDAO();
        this.medicoDAO = new MedicoDAO();
        this.citaDAO = new CitaDAO();
        
        configurarVentana();
        inicializarTablaCitas();
        cargarEspecialidades();
    }
    
    private void configurarVentana() {
        this.setTitle("Gestión de Citas");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    }
    
    private void inicializarTablaCitas() {
        citasTableModel = new DefaultTableModel(
            new Object[]{"ID", "Fecha/Hora", "Especialidad", "Médico", "Estado"}, 0) {
            
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        tblCitas.setModel(citasTableModel);
    }
    
    private void cargarEspecialidades() {
        listaEspecialidades = especialidadDAO.listarEspecialidades();
        
        DefaultComboBoxModel<Object> model = new DefaultComboBoxModel<>();
        model.addElement("-- Seleccione --"); 
        for (Especialidad esp : listaEspecialidades) {
            model.addElement(esp);
        }
        cmbEspecialidad.setModel(model);
        
        // Listener para actualizar médicos y costo
        cmbEspecialidad.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED && cmbEspecialidad.getSelectedIndex() > 0) {
                Especialidad esp = (Especialidad) cmbEspecialidad.getSelectedItem();
                cargarMedicosPorEspecialidad(esp.getIdEspecialidad());
                txtCosto.setText(String.format("S/ %.2f", esp.getPrecioConsulta()));
            } else {
                cmbMedico.setModel(new DefaultComboBoxModel<>());
                txtCosto.setText("");
            }
        });
    }
    
    private void cargarMedicosPorEspecialidad(int idEspecialidad) {
        List<Medico> medicos = medicoDAO.listarMedicosPorEspecialidad(idEspecialidad);
        DefaultComboBoxModel<Object> model = new DefaultComboBoxModel<>();
        model.addElement("-- Seleccione --"); 
        for (Medico med : medicos) {
            model.addElement(med);
        }
        cmbMedico.setModel(model);
    }
    
    private void cargarCitasDelPaciente() {
        citasTableModel.setRowCount(0);
        if (pacienteActual == null) return;
        
        listaCitasPaciente = citaDAO.listarCitasPorPaciente(pacienteActual.getIdPaciente());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        
        for (Cita c : listaCitasPaciente) {
            citasTableModel.addRow(new Object[]{
                c.getIdCita(),
                c.getFechaHora().format(formatter),
                c.getNombreEspecialidad(),
                c.getNombreMedico(),
                c.getEstadoPago()
            });
        }
    }
    
    private void limpiarFormularioCita() {
        citaSeleccionada = null;
        cmbEspecialidad.setSelectedIndex(0);
        cmbMedico.setModel(new DefaultComboBoxModel<>());
        jdcFechaCita.setDate(null);
        txtHoraCita.setText("");
        txtMalestarMotivo.setText("");
        txtCosto.setText("");
        tblCitas.clearSelection();
    }
    
    private LocalDateTime validarFechaHora() {
        Date fecha = jdcFechaCita.getDate();
        String horaStr = txtHoraCita.getText().trim();
        
        if (fecha == null || horaStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una fecha y una hora (HH:mm).", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
            return null;
        }

        LocalDate fechaSeleccionada = fecha.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        
        if (fechaSeleccionada.isBefore(LocalDate.now())) {
            JOptionPane.showMessageDialog(this, "La fecha no puede ser anterior al día de hoy.", "Fecha Inválida", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        
        LocalTime horaSeleccionada;
        try {
            horaSeleccionada = LocalTime.parse(horaStr, DateTimeFormatter.ofPattern("HH:mm"));
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this, "El formato de hora debe ser HH:mm (ej. 14:30).", "Formato Inválido", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        
        LocalDateTime fechaHoraCita = LocalDateTime.of(fechaSeleccionada, horaSeleccionada);
        
        if (fechaHoraCita.isBefore(LocalDateTime.now())) {
            JOptionPane.showMessageDialog(this, "La hora seleccionada ya ha pasado.", "Hora Inválida", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        
        return fechaHoraCita;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtDniPaciente = new javax.swing.JTextField();
        btnBuscarPaciente = new javax.swing.JButton();
        txtNombresPaciente = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cmbEspecialidad = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cmbMedico = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jdcFechaCita = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        txtHoraCita = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtMalestarMotivo = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        txtCosto = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnImprimir = new javax.swing.JButton();
        btnEnviar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCitas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("Cita médica");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("DNI:");

        btnBuscarPaciente.setText("Buscar");
        btnBuscarPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarPacienteActionPerformed(evt);
            }
        });

        txtNombresPaciente.setEditable(false);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Nombres y Apellidos:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Especialidad:");

        cmbEspecialidad.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Médico:");

        cmbMedico.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setText("Fecha:");

        jLabel7.setText("Hora (HH:mm):");

        txtHoraCita.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtHoraCita.setText("Ej. 09:30");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setText("Malestar/Motivo:");

        txtMalestarMotivo.setColumns(20);
        txtMalestarMotivo.setRows(5);
        jScrollPane1.setViewportView(txtMalestarMotivo);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setText("Costo Consulta:");

        txtCosto.setEditable(false);

        btnGuardar.setText("Guardar");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnImprimir.setText("Imprimir");
        btnImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimirActionPerformed(evt);
            }
        });

        btnEnviar.setText("Enviar");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setText("Citas del paciente:");

        tblCitas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblCitas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCitasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblCitas);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(234, 234, 234)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(81, 81, 81)
                        .addComponent(btnEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(85, 85, 85)))
                .addGap(92, 92, 92))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(59, 59, 59)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(txtDniPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(btnBuscarPaciente))
                                .addComponent(txtNombresPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel6)
                                .addComponent(jLabel4)
                                .addComponent(jLabel8)
                                .addComponent(jLabel9)
                                .addComponent(jLabel10))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(cmbEspecialidad, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jdcFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel5)
                                        .addComponent(jLabel7))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtHoraCita)
                                        .addComponent(cmbMedico, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 447, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(txtHoraCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtDniPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBuscarPaciente))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtNombresPaciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(cmbEspecialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(cmbMedico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jdcFechaCita, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnImprimir, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if (pacienteActual == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un paciente.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (cmbEspecialidad.getSelectedIndex() <= 0 || cmbMedico.getSelectedIndex() <= 0) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar especialidad y médico.", "Campos Vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        LocalDateTime fechaHora = validarFechaHora();
        if (fechaHora == null) return;

        Especialidad esp = (Especialidad) cmbEspecialidad.getSelectedItem();
        Medico med = (Medico) cmbMedico.getSelectedItem();
        
        Cita nuevaCita = new Cita();
        nuevaCita.setIdPaciente(pacienteActual.getIdPaciente());
        nuevaCita.setIdEspecialidad(esp.getIdEspecialidad());
        nuevaCita.setIdMedico(med.getIdMedico());
        nuevaCita.setFechaHora(fechaHora);
        nuevaCita.setMalestarMotivo(txtMalestarMotivo.getText().trim());
        nuevaCita.setCostoConsultaRegistrado(esp.getPrecioConsulta());
        
        if (citaDAO.registrarCita(nuevaCita)) {
            JOptionPane.showMessageDialog(this, "Cita registrada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            cargarCitasDelPaciente();
            limpiarFormularioCita();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        if (citaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una cita de la lista.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (citaSeleccionada.getEstadoPago().equals("PAGADA")) {
            JOptionPane.showMessageDialog(this, "No se puede modificar una cita que ya ha sido pagada.", "Acción Denegada", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDateTime fechaHora = validarFechaHora();
        if (fechaHora == null) return;
        
        Especialidad esp = (Especialidad) cmbEspecialidad.getSelectedItem();
        Medico med = (Medico) cmbMedico.getSelectedItem();
        
        citaSeleccionada.setIdEspecialidad(esp.getIdEspecialidad());
        citaSeleccionada.setIdMedico(med.getIdMedico());
        citaSeleccionada.setFechaHora(fechaHora);
        citaSeleccionada.setMalestarMotivo(txtMalestarMotivo.getText().trim());
        citaSeleccionada.setCostoConsultaRegistrado(esp.getPrecioConsulta());

        if (citaDAO.modificarCita(citaSeleccionada)) {
            JOptionPane.showMessageDialog(this, "Cita modificada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            cargarCitasDelPaciente();
            limpiarFormularioCita();
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        if (citaSeleccionada == null) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar una cita de la lista.", "Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (citaSeleccionada.getEstadoPago().equals("PAGADA")) {
            JOptionPane.showMessageDialog(this, "No se puede eliminar una cita que ya ha sido pagada.", "Acción Denegada", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar esta cita?", "Confirmar", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (citaDAO.eliminarCita(citaSeleccionada.getIdCita())) {
                JOptionPane.showMessageDialog(this, "Cita eliminada.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                cargarCitasDelPaciente();
                limpiarFormularioCita();
            }
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimirActionPerformed
        JOptionPane.showMessageDialog(this, "Función de Imprimir PDF pendiente.", "Pendiente", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnImprimirActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
        JOptionPane.showMessageDialog(this, "Función de Enviar Email pendiente.", "Pendiente", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnBuscarPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarPacienteActionPerformed
        String dni = txtDniPaciente.getText().trim();
        if (dni.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe ingresar un DNI.", "Campo Vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }

        pacienteActual = pacienteDAO.buscarPacientePorDNI(dni);

        if (pacienteActual != null) {
            txtNombresPaciente.setText(pacienteActual.getNombres() + " " + pacienteActual.getApellidos());
            cargarCitasDelPaciente();
        } else {
            JOptionPane.showMessageDialog(this, "Paciente no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            txtNombresPaciente.setText("");
            pacienteActual = null;
            citasTableModel.setRowCount(0);
        }
    }//GEN-LAST:event_btnBuscarPacienteActionPerformed

    private void tblCitasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCitasMouseClicked
        int fila = tblCitas.getSelectedRow();
        if (fila == -1) return;

        int idCita = (int) citasTableModel.getValueAt(fila, 0);
        
        // Buscar la cita en la lista cargada
        citaSeleccionada = listaCitasPaciente.stream()
            .filter(c -> c.getIdCita() == idCita)
            .findFirst()
            .orElse(null);
            
        if (citaSeleccionada == null) return;
        
        // --- Cargar datos en el formulario ---
        
        // 1. Cargar Especialidad (requiere encontrar el objeto)
        for (int i = 0; i < cmbEspecialidad.getItemCount(); i++) {
            if (cmbEspecialidad.getItemAt(i) instanceof Especialidad) {
                Especialidad esp = (Especialidad) cmbEspecialidad.getItemAt(i);
                if (esp.getIdEspecialidad() == citaSeleccionada.getIdEspecialidad()) {
                    cmbEspecialidad.setSelectedItem(esp);
                    break;
                }
            }
            }
        
        // 2. Cargar Médico (requiere que la especialidad esté cargada primero)
        // (El listener de cmbEspecialidad cargará los médicos, 
        // necesitamos esperar y seleccionar el correcto)
        
        // --- Esta parte es compleja, la simplificaremos por ahora ---
        // (La forma correcta requiere un SwingWorker o un listener complejo)
        // (Por ahora, cargamos los datos simples)
        
        Date fechaCita = Date.from(citaSeleccionada.getFechaHora().atZone(ZoneId.systemDefault()).toInstant());
        jdcFechaCita.setDate(fechaCita);
        
        txtHoraCita.setText(citaSeleccionada.getFechaHora().format(DateTimeFormatter.ofPattern("HH:mm")));
        txtMalestarMotivo.setText(citaSeleccionada.getMalestarMotivo());
        txtCosto.setText(String.format("S/ %.2f", citaSeleccionada.getCostoConsultaRegistrado()));
        
        // (Falta seleccionar el médico correcto)
    }//GEN-LAST:event_tblCitasMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarPaciente;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JButton btnModificar;
    private javax.swing.JComboBox<Object> cmbEspecialidad;
    private javax.swing.JComboBox<Object> cmbMedico;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private com.toedter.calendar.JDateChooser jdcFechaCita;
    private javax.swing.JTable tblCitas;
    private javax.swing.JTextField txtCosto;
    private javax.swing.JTextField txtDniPaciente;
    private javax.swing.JTextField txtHoraCita;
    private javax.swing.JTextArea txtMalestarMotivo;
    private javax.swing.JTextField txtNombresPaciente;
    // End of variables declaration//GEN-END:variables
}
