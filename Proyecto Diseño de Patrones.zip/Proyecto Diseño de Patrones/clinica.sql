-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: clinica
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `citas`
--

DROP TABLE IF EXISTS `citas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `citas` (
  `id_cita` int NOT NULL AUTO_INCREMENT,
  `id_paciente` int NOT NULL,
  `id_medico` int NOT NULL,
  `id_especialidad` int NOT NULL,
  `fecha_hora` datetime NOT NULL,
  `malestar_motivo` text,
  `costo_consulta_registrado` decimal(10,2) NOT NULL,
  `estado_pago` enum('PENDIENTE','PAGADA') NOT NULL DEFAULT 'PENDIENTE',
  PRIMARY KEY (`id_cita`),
  KEY `id_paciente` (`id_paciente`),
  KEY `id_medico` (`id_medico`),
  KEY `id_especialidad` (`id_especialidad`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`),
  CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`id_medico`) REFERENCES `medicos` (`id_medico`),
  CONSTRAINT `citas_ibfk_3` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidades` (`id_especialidad`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citas`
--

LOCK TABLES `citas` WRITE;
/*!40000 ALTER TABLE `citas` DISABLE KEYS */;
INSERT INTO `citas` VALUES (1,1,1,1,'2025-11-18 20:30:00','Dolor pecho fuerte',150.00,'PAGADA');
/*!40000 ALTER TABLE `citas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultas`
--

DROP TABLE IF EXISTS `consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultas` (
  `id_consulta` int NOT NULL AUTO_INCREMENT,
  `id_cita` int NOT NULL,
  `diagnostico` text,
  `fecha_consulta` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_consulta`),
  UNIQUE KEY `id_cita` (`id_cita`),
  CONSTRAINT `consultas_ibfk_1` FOREIGN KEY (`id_cita`) REFERENCES `citas` (`id_cita`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultas`
--

LOCK TABLES `consultas` WRITE;
/*!40000 ALTER TABLE `consultas` DISABLE KEYS */;
INSERT INTO `consultas` VALUES (1,1,'Pre-Infarto','2025-11-17 04:01:28');
/*!40000 ALTER TABLE `consultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidades`
--

DROP TABLE IF EXISTS `especialidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `especialidades` (
  `id_especialidad` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `precio_consulta` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_especialidad`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidades`
--

LOCK TABLES `especialidades` WRITE;
/*!40000 ALTER TABLE `especialidades` DISABLE KEYS */;
INSERT INTO `especialidades` VALUES (1,'Cardiología',150.00),(2,'Dermatología',130.00),(3,'Pediatría',120.00),(4,'Ginecología',140.00),(5,'Traumatología',135.00),(6,'Medicina General',100.00);
/*!40000 ALTER TABLE `especialidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_detalle`
--

DROP TABLE IF EXISTS `factura_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `factura_detalle` (
  `id_factura_detalle` int NOT NULL AUTO_INCREMENT,
  `id_factura` int NOT NULL,
  `id_cita` int DEFAULT NULL,
  `id_medicina` int DEFAULT NULL,
  `descripcion` varchar(255) NOT NULL,
  `cantidad_vendida` int NOT NULL,
  `precio_venta_unitario` decimal(10,2) NOT NULL,
  `costo_unitario` decimal(10,2) NOT NULL,
  `id_receta_medicamento` int DEFAULT NULL,
  PRIMARY KEY (`id_factura_detalle`),
  KEY `id_factura` (`id_factura`),
  KEY `id_cita` (`id_cita`),
  KEY `id_medicina` (`id_medicina`),
  KEY `id_receta_medicamento` (`id_receta_medicamento`),
  CONSTRAINT `factura_detalle_ibfk_1` FOREIGN KEY (`id_factura`) REFERENCES `facturas` (`id_factura`) ON DELETE CASCADE,
  CONSTRAINT `factura_detalle_ibfk_2` FOREIGN KEY (`id_cita`) REFERENCES `citas` (`id_cita`),
  CONSTRAINT `factura_detalle_ibfk_3` FOREIGN KEY (`id_medicina`) REFERENCES `medicinas` (`id_medicina`),
  CONSTRAINT `factura_detalle_ibfk_4` FOREIGN KEY (`id_receta_medicamento`) REFERENCES `receta_medicamentos` (`id_receta`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_detalle`
--

LOCK TABLES `factura_detalle` WRITE;
/*!40000 ALTER TABLE `factura_detalle` DISABLE KEYS */;
INSERT INTO `factura_detalle` VALUES (1,1,1,NULL,'Consulta Cardiología',1,150.00,0.00,NULL),(2,2,NULL,1,'Paracetamol 500mg',1,0.50,0.20,1);
/*!40000 ALTER TABLE `factura_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturas`
--

DROP TABLE IF EXISTS `facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facturas` (
  `id_factura` int NOT NULL AUTO_INCREMENT,
  `id_paciente` int NOT NULL,
  `fecha_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `metodo_pago` enum('YAPE','PLIN','TARJETA','EFECTIVO') NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `igv` decimal(10,2) NOT NULL,
  `total_importe` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_factura`),
  KEY `id_paciente` (`id_paciente`),
  CONSTRAINT `facturas_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturas`
--

LOCK TABLES `facturas` WRITE;
/*!40000 ALTER TABLE `facturas` DISABLE KEYS */;
INSERT INTO `facturas` VALUES (1,1,'2025-11-17 04:00:14','EFECTIVO',127.12,22.88,150.00),(2,1,'2025-11-17 04:22:03','YAPE',0.42,0.08,0.50);
/*!40000 ALTER TABLE `facturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_medico_previo`
--

DROP TABLE IF EXISTS `historial_medico_previo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_medico_previo` (
  `id_historial` int NOT NULL AUTO_INCREMENT,
  `id_paciente` int NOT NULL,
  `malestar_motivo` text,
  `id_especialidad` int DEFAULT NULL,
  `atendio_clinica` tinyint(1) NOT NULL DEFAULT '0',
  `medico_externo` varchar(255) DEFAULT NULL,
  `fecha_atencion` varchar(50) DEFAULT NULL,
  `no_recuerda_fecha` tinyint(1) DEFAULT '0',
  `diagnostico` text,
  `medicamentos_recordados` text,
  PRIMARY KEY (`id_historial`),
  KEY `id_paciente` (`id_paciente`),
  KEY `id_especialidad` (`id_especialidad`),
  CONSTRAINT `historial_medico_previo_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `pacientes` (`id_paciente`),
  CONSTRAINT `historial_medico_previo_ibfk_2` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidades` (`id_especialidad`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_medico_previo`
--

LOCK TABLES `historial_medico_previo` WRITE;
/*!40000 ALTER TABLE `historial_medico_previo` DISABLE KEYS */;
/*!40000 ALTER TABLE `historial_medico_previo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinas`
--

DROP TABLE IF EXISTS `medicinas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinas` (
  `id_medicina` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `cantidad_stock` int NOT NULL DEFAULT '0',
  `costo_unitario` decimal(10,2) NOT NULL,
  `precio_venta_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_medicina`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinas`
--

LOCK TABLES `medicinas` WRITE;
/*!40000 ALTER TABLE `medicinas` DISABLE KEYS */;
INSERT INTO `medicinas` VALUES (1,'Paracetamol 500mg',999,0.20,0.50),(2,'Amoxicilina 250mg',500,0.50,1.20),(3,'Ibuprofeno 400mg',800,0.30,0.80),(4,'Omeprazol 20mg',300,0.80,2.00),(5,'Loratadina 10mg',400,0.40,1.00),(6,'Panadol Antigripal',200,1.00,2.50),(7,'Aspirina 100mg',500,0.15,0.40);
/*!40000 ALTER TABLE `medicinas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico_especialidades`
--

DROP TABLE IF EXISTS `medico_especialidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medico_especialidades` (
  `id_medico` int NOT NULL,
  `id_especialidad` int NOT NULL,
  PRIMARY KEY (`id_medico`,`id_especialidad`),
  KEY `id_especialidad` (`id_especialidad`),
  CONSTRAINT `medico_especialidades_ibfk_1` FOREIGN KEY (`id_medico`) REFERENCES `medicos` (`id_medico`) ON DELETE CASCADE,
  CONSTRAINT `medico_especialidades_ibfk_2` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidades` (`id_especialidad`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico_especialidades`
--

LOCK TABLES `medico_especialidades` WRITE;
/*!40000 ALTER TABLE `medico_especialidades` DISABLE KEYS */;
INSERT INTO `medico_especialidades` VALUES (1,1),(7,1),(2,2),(8,2),(3,3),(9,3),(4,4),(5,5),(1,6),(4,6),(6,6),(10,6);
/*!40000 ALTER TABLE `medico_especialidades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicos`
--

DROP TABLE IF EXISTS `medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicos` (
  `id_medico` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `codigo_medico` varchar(50) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_medico`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  UNIQUE KEY `codigo_medico` (`codigo_medico`),
  CONSTRAINT `medicos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicos`
--

LOCK TABLES `medicos` WRITE;
/*!40000 ALTER TABLE `medicos` DISABLE KEYS */;
INSERT INTO `medicos` VALUES (1,4,'CMP0001','999000101'),(2,5,'CMP0002','999000102'),(3,6,'CMP0003','999000103'),(4,7,'CMP0004','999000104'),(5,8,'CMP0005','999000105'),(6,9,'CMP0006','999000106'),(7,10,'CMP0007','999000107'),(8,11,'CMP0008','999000108'),(9,12,'CMP0009','999000109'),(10,13,'CMP0010','999000110');
/*!40000 ALTER TABLE `medicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pacientes`
--

DROP TABLE IF EXISTS `pacientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pacientes` (
  `id_paciente` int NOT NULL AUTO_INCREMENT,
  `dni` varchar(15) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` enum('MASCULINO','FEMENINO','OTROS') NOT NULL,
  `ocupacion` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_paciente`),
  UNIQUE KEY `dni` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pacientes`
--

LOCK TABLES `pacientes` WRITE;
/*!40000 ALTER TABLE `pacientes` DISABLE KEYS */;
INSERT INTO `pacientes` VALUES (1,'40000001','Juan','Perez','1990-05-15','MASCULINO','Ingeniero','Av. Arequipa 123','987654321','jperez@mail.com'),(2,'40000002','Maria','Garcia','1985-11-20','FEMENINO','Abogada','Calle Los Olivos 456','987654322','mgarcia@mail.com'),(3,'40000003','Carlos','Rodriguez','2000-01-30','MASCULINO','Estudiante','Jr. De la Union 789','987654323','carlosr@mail.com'),(4,'40000004','Ana','Martinez','1995-07-22','FEMENINO','Doctora','Av. Javier Prado 101','987654324','anamart@mail.com'),(5,'40000005','Luis','Fernandez','1988-03-10','MASCULINO','Contador','Calle Las Begonias 202','987654325','luisf@mail.com'),(6,'40000006','Laura','Sanchez','1992-09-05','FEMENINO','Diseñadora','Av. Benavides 303','987654326','lauras@mail.com'),(7,'40000007','Pedro','Gomez','1976-12-12','MASCULINO','Taxista','Jr. Ica 404','987654327','pedrog@mail.com'),(8,'40000008','Sofia','Torres','2002-02-18','FEMENINO','Estudiante','Av. Angamos 505','987654328','sofiat@mail.com'),(9,'40000009','Miguel','Diaz','1980-08-08','MASCULINO','Policia','Calle Berlin 606','987654329','migueld@mail.com'),(10,'40000010','Lucia','Ramirez','1998-04-25','FEMENINO','Enfermera','Av. Primavera 707','987654330','luciar@mail.com'),(11,'40000011','Javier','Morales','1991-06-14','MASCULINO','Arquitecto','Calle Alcanfores 808','987654331','javierm@mail.com'),(12,'40000012','Elena','Vargas','1983-10-30','FEMENINO','Profesora','Av. La Marina 909','987654332','elenav@mail.com'),(13,'40000013','Diego','Castro','1993-01-20','MASCULINO','Musico','Jr. Cusco 111','987654333','diegoc@mail.com'),(14,'40000014','Camila','Rojas','2001-07-11','FEMENINO','Estudiante','Av. Grau 222','987654334','camilar@mail.com'),(15,'40000015','Andres','Silva','1979-11-03','MASCULINO','Chef','Calle Pardo 333','987654335','andress@mail.com'),(16,'40000016','Valeria','Gutierrez','1996-05-19','FEMENINO','Periodista','Av. Salaverry 444','987654336','valeriag@mail.com'),(17,'40000017','Jorge','Mendoza','1982-02-28','MASCULINO','Vendedor','Jr. Huallaga 555','987654337','jorgem@mail.com'),(18,'40000018','Daniela','Paredes','1999-08-17','FEMENINO','Psicologa','Av. Arequipa 666','987654338','danielap@mail.com'),(19,'40000019','Ricardo','Chavez','1975-04-09','MASCULINO','Obrero','Calle Los Jazmines 777','987654339','ricardoc@mail.com'),(20,'40000020','Gabriela','Ortiz','1990-12-01','FEMENINO','Traductora','Av. Ejercito 888','987654340','gabio@mail.com'),(21,'40000021','Roberto','Flores','1987-03-23','MASCULINO','Ingeniero','Av. Pardo y Aliaga 999','987654341','rf@mail.com'),(22,'40000022','Paula','Castillo','1994-10-14','FEMENINO','Nutricionista','Calle Los Manzanos 100','987654342','pc@mail.com'),(23,'40000023','Martin','Iglesias','1981-06-07','MASCULINO','Abogado','Jr. Lampa 200','987654343','mi@mail.com'),(24,'40000024','Natalia','Guerrero','2003-09-02','FEMENINO','Estudiante','Av. 28 de Julio 300','987654344','ng@mail.com'),(25,'40000025','Oscar','Luna','1997-12-29','MASCULINO','Programador','Calle Schell 400','987654345','ol@mail.com'),(26,'40000026','Beatriz','Campos','1984-08-11','FEMENINO','Contadora','Av. Comandante Espinar 500','987654346','bc@mail.com'),(27,'40000027','Ivan','Reyes','1978-05-06','MASCULINO','Electricista','Calle Tarata 600','987654347','ir@mail.com'),(28,'40000028','Jimena','Soto','1992-01-24','FEMENINO','Diseñadora','Jr. Paruro 700','987654348','js@mail.com'),(29,'40000029','Marcos','Delgado','1989-11-16','MASCULINO','Mecanico','Av. Mexico 800','987654349','md@mail.com'),(30,'40000030','Tatiana','Salazar','1995-04-03','FEMENINO','Secretaria','Calle Capon 900','987654350','ts@mail.com'),(31,'40000031','Alejandro','Vidal','1986-10-10','MASCULINO','Ingeniero','Av. Abancay 111','987654351','av@mail.com'),(32,'40000032','Carla','Quispe','1990-02-15','FEMENINO','Cajera','Jr. Ucayali 222','987654352','cq@mail.com'),(33,'40000033','David','Huaman','1977-07-07','MASCULINO','Conductor','Av. Tacna 333','987654353','dh@mail.com'),(34,'40000034','Estefania','Leon','2000-09-21','FEMENINO','Estudiante','Calle Gamarra 444','987654354','el@mail.com'),(35,'40000035','Fernando','Machado','1983-04-12','MASCULINO','Profesor','Av. Wilson 555','987654355','fm@mail.com'),(36,'40000036','Gloria','Benites','1993-01-05','FEMENINO','Enfermera','Jr. Azangaro 666','987654356','gb@mail.com'),(37,'40000037','Hector','Cabrera','1980-03-30','MASCULINO','Cocinero','Av. Alfonso Ugarte 777','987654357','hc@mail.com'),(38,'40000038','Ines','Farfan','1998-11-23','FEMENINO','Recepcionista','Calle Ocoña 888','987654358','if@mail.com'),(39,'40000039','Leonardo','Yauri','1985-08-16','MASCULINO','Vigilante','Av. Emancipacion 999','987654359','ly@mail.com'),(40,'40000040','Monica','Zevallos','1996-06-08','FEMENINO','Marketera','Calle Porta 121','987654360','mz@mail.com'),(41,'40000041','Nicolas','Acosta','1991-02-11','MASCULINO','Publicista','Calle Esperanza 232','987654361','na@mail.com'),(42,'40000042','Olivia','Bustamante','1987-10-04','FEMENINO','Abogada','Av. Larco 343','987654362','ob@mail.com'),(43,'40000043','Pablo','Cordova','1979-12-19','MASCULINO','Ingeniero','Calle Cantuarias 454','987654363','pc@mail.com'),(44,'40000044','Raquel','Davila','1994-07-28','FEMENINO','Contadora','Av. Reducto 565','987654364','rd@mail.com'),(45,'40000045','Sergio','Espinosa','1982-05-13','MASCULINO','Gerente','Jr. Camaná 676','987654365','se@mail.com'),(46,'40000046','Teresa','Fuentes','1999-03-01','FEMENINO','Estudiante','Calle San Martin 787','987654366','tf@mail.com'),(47,'40000047','Victor','Heredia','1988-09-09','MASCULINO','Taxista','Av. Bolognesi 898','987654367','vh@mail.com'),(48,'40000048','Wendy','Ibarra','1997-01-17','FEMENINO','Secretaria','Calle Colon 909','987654368','wi@mail.com'),(49,'40000049','Xavier','Jaimes','1984-11-07','MASCULINO','Militar','Av. Grau 112','987654369','xj@mail.com'),(50,'40000050','Yvone','Linares','1993-08-31','FEMENINO','Diseñadora','Jr. Quilca 223','987654370','yl@mail.com');
/*!40000 ALTER TABLE `pacientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receta_medicamentos`
--

DROP TABLE IF EXISTS `receta_medicamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receta_medicamentos` (
  `id_receta` int NOT NULL AUTO_INCREMENT,
  `id_consulta` int NOT NULL,
  `id_medicina` int NOT NULL,
  `dosis` text,
  `cantidad_prescrita` int NOT NULL,
  PRIMARY KEY (`id_receta`),
  KEY `id_consulta` (`id_consulta`),
  KEY `id_medicina` (`id_medicina`),
  CONSTRAINT `receta_medicamentos_ibfk_1` FOREIGN KEY (`id_consulta`) REFERENCES `consultas` (`id_consulta`),
  CONSTRAINT `receta_medicamentos_ibfk_2` FOREIGN KEY (`id_medicina`) REFERENCES `medicinas` (`id_medicina`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receta_medicamentos`
--

LOCK TABLES `receta_medicamentos` WRITE;
/*!40000 ALTER TABLE `receta_medicamentos` DISABLE KEYS */;
INSERT INTO `receta_medicamentos` VALUES (1,1,1,'Paracetamol 500mg',3);
/*!40000 ALTER TABLE `receta_medicamentos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `dni` varchar(15) NOT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `usuario` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `tipo_usuario` enum('ADMINISTRADOR','REGISTRADOR','MEDICO','CAJERO') NOT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `dni` (`dni`),
  UNIQUE KEY `usuario` (`usuario`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador','Principal','11111111','admin@clinica.com','admin','admin','ADMINISTRADOR'),(2,'Romina','Perez','22222222','reg@clinica.com','reg','reg','REGISTRADOR'),(3,'Carlos','Soto','33333333','caja@clinica.com','caja','caja','CAJERO'),(4,'Julio','Vargas','10000001','jvargas@clinica.com','jvargas','jvargas','MEDICO'),(5,'Maria','Lopez','10000002','mlopez@clinica.com','mlopez','mlopez','MEDICO'),(6,'Carlos','Ruiz','10000003','cruiz@clinica.com','cruiz','cruiz','MEDICO'),(7,'Ana','Torres','10000004','atorres@clinica.com','atorres','atorres','MEDICO'),(8,'Luis','Gonzales','10000005','lgonzales@clinica.com','lgonzales','lgonzales','MEDICO'),(9,'Sofia','Diaz','10000006','sdiaz@clinica.com','sdiaz','sdiaz','MEDICO'),(10,'Miguel','Chavez','10000007','mchavez@clinica.com','mchavez','mchavez','MEDICO'),(11,'Laura','Jimenez','10000008','ljimenez@clinica.com','ljimenez','ljimenez','MEDICO'),(12,'Pedro','Santos','10000009','psantos@clinica.com','psantos','psantos','MEDICO'),(13,'Lucia','Milla','10000010','lmilla@clinica.com','lmilla','lmilla','MEDICO');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-17  4:24:53
